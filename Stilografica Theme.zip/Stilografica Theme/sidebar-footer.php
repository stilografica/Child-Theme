<?php

include( DCE_PATH . '/child-includes/sidebar-footer.php' );

?>